package main

import (
	"fmt"
	"log"
	"trashgo/Models"

	"github.com/gofiber/fiber/v2"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

var DB *gorm.DB

func Connect() {
	dsn := "root:@tcp(127.0.0.1:3306)/trash_go?charset=utf8mb4&parseTime=True&loc=Local"
	con, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
	if err != nil {
		fmt.Println("Gagal Meng koneksikan database")
	}
	fmt.Println("database terkoneksi")
	DB = con
	con.AutoMigrate(&Models.User{})
}

func Register(c *fiber.Ctx) error {
	var data map[string]string
	if err := c.BodyParser(&data); err != nil {
		return err
	}
	password, _ := bcrypt.GenerateFromPassword([]byte(data["Password"]), bcrypt.DefaultCost)
	user := Models.User{
		Email:    data["email"],
		NamaUser: data["nama_user"],
		Password: password,
	}

	DB.Create(&user)

	return c.JSON(fiber.Map{
		"message": "Terima Kasih telah mendaftar di aplikasi kami",
	})
}

func Login(c *fiber.Ctx) error {

	var data map[string]string
	if err := c.BodyParser(&data); err != nil {
		return err
	}

	var user Models.User

	DB.Where("Email = ?", data["email"]).First(&user)

	if user.IDUser == 0 {
		c.Status(fiber.StatusBadRequest)
		return c.JSON(fiber.Map{
			"message": "User not found!",
		})
	}

	if err := bcrypt.CompareHashAndPassword(user.Password, []byte(data["Password"])); err != nil {
		c.Status(fiber.StatusBadRequest)
		return c.JSON(fiber.Map{
			"message": "Incorrect password!",
		})
	}
	return c.JSON(fiber.Map{
		"message": "hallo Selamat datang",
	})
}

func main() {

	Connect()
	app := fiber.New()
	app.Get("/hello", func(c *fiber.Ctx) error {
		return c.SendString("Hello, World!")
	})
	app.Post("/api/register", Register)
	app.Post("/api/login", Login)
	log.Fatal(app.Listen(":1234"))

}
